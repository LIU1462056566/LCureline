//
//  AppDelegate.h
//  LCureline
//
//  Created by 刘文超 on 2017/11/2.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

