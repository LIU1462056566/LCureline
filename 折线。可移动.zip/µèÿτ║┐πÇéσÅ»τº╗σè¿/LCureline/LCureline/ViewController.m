//
//  ViewController.m
//  LCureline
//
//  Created by 刘文超 on 2017/11/2.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "ViewController.h"
#import "LcureLine.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor yellowColor];
    LcureLine * zx = [[LcureLine alloc]initWithFrame:CGRectMake(10, 100, [UIScreen mainScreen].bounds.size.width - 20, 250)];
//
  NSArray *dataArray=@[@{@"x":@"1.29",@"y":@"5.48"},@{@"x":@"2.29",@"y":@"4.48"},@{@"x":@"3.29",@"y":@"3.48"},@{@"x":@"4.29",@"y":@"7.48"},@{@"x":@"5.29",@"y":@"8.48"},@{@"x":@"6.29",@"y":@"7.48"},@{@"x":@"8.29",@"y":@"3.48"},@{@"x":@"9.29",@"y":@"4.48"},@{@"x":@"10.29",@"y":@"5.48"},@{@"x":@"11.29",@"y":@"1.48"},@{@"x":@"12.29",@"y":@"4.48"},@{@"x":@"13.29",@"y":@"7.48"},@{@"x":@"14.29",@"y":@"4.48"},@{@"x":@"15.29",@"y":@"5.48"},@{@"x":@"16.29",@"y":@"1.48"},@{@"x":@"17.29",@"y":@"4.48"},@{@"x":@"18.29",@"y":@"7.48"}];
    zx.dataArray=dataArray;
    [self.view addSubview:zx];
    
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
