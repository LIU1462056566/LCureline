//
//  LcureLine.h
//  LCureline
//
//  Created by 刘文超 on 2017/11/2.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LcureLine : UIView
@property (nonatomic,strong)NSArray * dataArray;
- (instancetype)initWithFrame:(CGRect)frame;
@end
