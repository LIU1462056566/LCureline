//
//  LcureLine.m
//  LCureline
//
//  Created by 刘文超 on 2017/11/2.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "LcureLine.h"

@interface LcureLine ()
{
    CGFloat maxValuey;
    CGFloat minValuey;
 
    CGFloat gap1;
}
@property (nonatomic, strong) CAShapeLayer *lineChartLayer;
@property (nonatomic, strong)UIBezierPath * path1;
/** 渐变背景视图 */
@property (nonatomic, strong) UIView *gradientBackgroundView;
/** 渐变图层 */
@property (nonatomic, strong) CAGradientLayer *gradientLayer;
/** 颜色数组 */
@property (nonatomic, strong) NSMutableArray *gradientLayerColors;

@property(nonatomic,strong)UIScrollView *lwc_myscrollView;

@end

@implementation LcureLine

static CGFloat bounceX = 50;
static CGFloat bounceY = 20;
static CGFloat spaceX = 10;
//static NSInteger countq = 0;
- (void)drawRect:(CGRect)rect{
    /*******画出坐标轴********/
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context, 2.0);
    CGContextSetRGBStrokeColor(context, 1, 0, 0, 1);
    CGContextMoveToPoint(context, bounceX, 0);
    CGContextAddLineToPoint(context, bounceX, rect.size.height - bounceY*2);
    CGContextAddLineToPoint(context,rect.size.width-spaceX, rect.size.height - bounceY*2);
    CGContextStrokePath(context);
    
}

#pragma mark 创建x轴的数据
- (void)createLabelX:(NSArray *)dataArr{
    
  
    CGFloat space_gap=(self.frame.size.width-bounceX-spaceX)/12;
    
    
    
    for (NSInteger i = 0; i < dataArr.count; i++) {
        UILabel * LabelMonth = [[UILabel alloc]initWithFrame:CGRectMake(space_gap*i, self.frame.size.height - spaceX , space_gap+bounceX, bounceY)];
        //       LabelMonth.backgroundColor = [UIColor greenColor];
        LabelMonth.tag = 1000 + i;
        LabelMonth.text = dataArr[i][@"x"];
        LabelMonth.font = [UIFont systemFontOfSize:10];
        LabelMonth.transform = CGAffineTransformMakeRotation(M_PI * 0.3);
        [self.lwc_myscrollView addSubview:LabelMonth];
    }
    
}


#pragma mark 改变最大值和最小值
-(void)changeMaxAndMinValue:(NSArray *)dataArr{
    CGFloat padValue;
    
    NSMutableArray *array=[[NSMutableArray alloc]init];
    [dataArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [array addObject:obj[@"y"]];
    }];
    
    //Y：
  CGFloat  maxValuey1 = [[array valueForKeyPath:@"@max.floatValue"] floatValue];
 CGFloat   minValuey1 = [[array valueForKeyPath:@"@min.floatValue"] floatValue];
    
   padValue = (maxValuey1 - minValuey1) / 6;

    
   maxValuey = padValue+maxValuey1;
   minValuey = minValuey1-padValue;
}


#pragma mark 创建y轴数据
- (void)createLabelY:(NSArray *)dataArr{
    
    
    //改变最大值。最小值
    [self changeMaxAndMinValue:dataArr];
    
    
    CGFloat Ydivision = 7;

    
    gap1=(maxValuey-minValuey)/6;

     CGFloat padRealValue = (self.frame.size.height - 2 * bounceY)/6;
    
    for (NSInteger i = 0; i < Ydivision; i++) {
        UILabel * labelYdivision = [[UILabel alloc]initWithFrame:CGRectMake(0,padRealValue*i, bounceY*2+spaceX, bounceY/2.0)];
        labelYdivision.textAlignment=NSTextAlignmentCenter;
        //   labelYdivision.backgroundColor = [UIColor greenColor];
        labelYdivision.tag = 2000 + i;
           labelYdivision.text = [NSString stringWithFormat:@"%.2f",maxValuey-gap1*i];

       
        labelYdivision.font = [UIFont systemFontOfSize:10];
        [self addSubview:labelYdivision];
    }
}

// 这两函数在 view的初始化方法里面调用
 - (instancetype)initWithFrame:(CGRect)frame{
 if (self = [super initWithFrame:frame]) {
 //   self.my
    self.backgroundColor = [UIColor whiteColor];
     //背景图
    [self drawGradientBackgroundView];
     
    self.lwc_myscrollView=[[UIScrollView alloc]init];
     self.lwc_myscrollView.bounces=NO;
     self.lwc_myscrollView.showsHorizontalScrollIndicator=NO;
    [self addSubview:self.lwc_myscrollView];
     
   

 }
 return self;
 }
-(void)layoutSubviews
{
    [super layoutSubviews];
    
    
    self.lwc_myscrollView.frame=CGRectMake(bounceX, 0, self.frame.size.width-bounceX-spaceX, self.frame.size.height);
    
}
-(void)setDataArray:(NSArray *)dataArray
{
    _dataArray=dataArray;
    
    
    //根据数据来改变折线的长度
   CGFloat space_gap=(self.frame.size.width-bounceX-spaceX)/12;
  self.lwc_myscrollView.contentSize=CGSizeMake((dataArray.count+1)*space_gap, self.frame.size.height);
 
    
    
    [self createLabelX:dataArray];
    
    [self createLabelY:dataArray];
    
    [self setLineDash];

    
    [self dravLine:dataArray];
    
    
    
    
}
#pragma mark 渐变的颜色
- (void)drawGradientBackgroundView {
    // 渐变背景视图（不包含坐标轴）
    self.gradientBackgroundView = [[UIView alloc] initWithFrame:CGRectMake(bounceX, 0, self.bounds.size.width - bounceX-spaceX, self.bounds.size.height - 2*bounceY)];
    [self addSubview:self.gradientBackgroundView];
    /** 创建并设置渐变背景图层 */
    //初始化CAGradientlayer对象，使它的大小为渐变背景视图的大小
    self.gradientLayer = [CAGradientLayer layer];
    self.gradientLayer.frame = self.gradientBackgroundView.bounds;
    //设置渐变区域的起始和终止位置（范围为0-1），即渐变路径
    self.gradientLayer.startPoint = CGPointMake(0, 0.0);
    self.gradientLayer.endPoint = CGPointMake(1.0, 0.0);
    //设置颜色的渐变过程
    self.gradientLayerColors = [NSMutableArray arrayWithArray:@[(__bridge id)[UIColor greenColor].CGColor, (__bridge id)[UIColor redColor].CGColor]];
    self.gradientLayer.colors = self.gradientLayerColors;
    //将CAGradientlayer对象添加在我们要设置背景色的视图的layer层
    [self.gradientBackgroundView.layer addSublayer:self.gradientLayer];
    //[self.layer addSublayer:self.gradientLayer];
}




//#pragma mark 点击重新绘制折线和背景
//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
//    countq++;
//    if (countq%2 == 0) {
//        [self.lineChartLayer removeFromSuperlayer];
//        for (NSInteger i = 0; i < 12; i++) {
//            UILabel * label = (UILabel*)[self viewWithTag:3000 + i];
//            [label removeFromSuperview];
//        }
//    }else{
//        
//        [self dravLine];
//        
//        self.lineChartLayer.lineWidth = 2;
//        CABasicAnimation *pathAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
//        pathAnimation.duration = 3;
//        pathAnimation.repeatCount = 1;
//        pathAnimation.removedOnCompletion = YES;
//        pathAnimation.fromValue = [NSNumber numberWithFloat:0.0f];
//        pathAnimation.toValue = [NSNumber numberWithFloat:1.0f];
//        // 设置动画代理，动画结束时添加一个标签，显示折线终点的信息
////        pathAnimation.delegate = self;
//        [self.lineChartLayer addAnimation:pathAnimation forKey:@"strokeEnd"];
//        //[self setNeedsDisplay];
//    }
//}
//- (void)animationDidStart:(CAAnimation *)anim{
//    NSLog(@"开始®");
//}
//- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag{
//    NSLog(@"停止~~~~~~~~");
//}
#pragma mark 画折线图
- (void)dravLine:(NSArray *)dataArr{
    
    UILabel * label = (UILabel*)[self viewWithTag:1000];
    CGFloat space_gap=(self.frame.size.width-bounceX-spaceX)/12;
    
    //转换坐标点
    
    UIBezierPath * path = [[UIBezierPath alloc]init];
    path.lineWidth = 1.0;
    self.path1 = path;
    UIColor * color = [UIColor greenColor];
    [color set];
    CGFloat minPrice=minValuey;
    CGFloat maxPrice=maxValuey;
    CGFloat yHeight = maxPrice- minPrice ; // y的价格高度
     CGFloat yViewHeight = (self.frame.size.height-bounceY*2) ;// y的实际像素高度
    //创建折现点标记
    for (NSInteger i = 0; i< dataArr.count; i++) {
        UILabel * label1 = (UILabel*)[self viewWithTag:1000 + i];
        CGFloat  arc = [dataArr[i][@"y"] floatValue];
        
        // 换算成实际的坐标
        CGFloat heightPointY = yViewHeight * (1 - ([dataArr[i][@"y"] floatValue] - minValuey) / yHeight);
        
        
        if (i==0) {
             [path moveToPoint:CGPointMake( label.frame.origin.x ,heightPointY)];
        }else{
            [path addLineToPoint:CGPointMake(label1.frame.origin.x,heightPointY)];
        }
      
        UILabel * falglabel = [[UILabel alloc]initWithFrame:CGRectMake(label1.frame.origin.x,heightPointY , 30, 15)];
        //  falglabel.backgroundColor = [UIColor blueColor];
        falglabel.tag = 3000+ i;
        falglabel.text = [NSString stringWithFormat:@"%.1f",arc];
        falglabel.font = [UIFont systemFontOfSize:8.0];
        [self.lwc_myscrollView addSubview:falglabel];
    }
    // [path stroke];
    
    self.lineChartLayer = [CAShapeLayer layer];
    self.lineChartLayer.path = path.CGPath;
    self.lineChartLayer.strokeColor = [UIColor whiteColor].CGColor;
    self.lineChartLayer.fillColor = [[UIColor clearColor] CGColor];
//     默认设置路径宽度为0，使其在起始状态下不显示
    self.lineChartLayer.lineWidth = 1;
    self.lineChartLayer.lineCap = kCALineCapRound;
    self.lineChartLayer.lineJoin = kCALineJoinRound;
    
    [self.lwc_myscrollView.layer addSublayer:self.lineChartLayer];//直接添加导视图上
    //   self.gradientBackgroundView.layer.mask = self.lineChartLayer;//添加到渐变图层
    
}
#pragma mark 添加虚线
- (void)setLineDash{
    
    for (NSInteger i = 0;i < 6; i++ ) {
        CAShapeLayer * dashLayer = [CAShapeLayer layer];
        dashLayer.strokeColor = [UIColor whiteColor].CGColor;
        dashLayer.fillColor = [[UIColor clearColor] CGColor];
        // 默认设置路径宽度为0，使其在起始状态下不显示
        dashLayer.lineWidth = 1.0;
        
        
        UILabel * label1 = (UILabel*)[self viewWithTag:2000 + i];
        
        UIBezierPath * path = [[UIBezierPath alloc]init];
        path.lineWidth = 1.0;
        UIColor * color = [UIColor blueColor];
        
        [color set];
        [path moveToPoint:CGPointMake( 0, label1.frame.origin.y)];
        [path addLineToPoint:CGPointMake(self.frame.size.width - spaceX,label1.frame.origin.y)];
        CGFloat dash[] = {10,10};
        [path setLineDash:dash count:2 phase:10];
        [path stroke];
        dashLayer.path = path.CGPath;
        [self.gradientBackgroundView.layer addSublayer:dashLayer];
    }
}


@end
